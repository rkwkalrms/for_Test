function f1() {
			alert('abc');	//sysout---> 'alert창'띄어줌 자바에 sysout랑 같은 기능			// 브라우저 마다 실행 순서가 달라 출력되는 순서가 다름
			var str = "익숙해지세요";		/*//var은 타입이 아니고 그냥 변수를 선언한다는 뜻이고 자바스크립트는 변수를 정하고 선언하지않는다.		//변수 선언 면접에서 5% 확률로 물어봄. */
			document.write(str);
		}